import React from 'react';

const Thead=()=> {
    return(
        <thead style={{background:'black', color:'white'}}>
            <tr>
                
                <td>Event Name</td>
                <td>Start</td>
                <td>End</td>
                <td>Start Booking </td>
                
                <td>End Booking</td>
                
            </tr>
        </thead>
    )
}

export default Thead ;