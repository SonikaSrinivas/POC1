import React, { Component } from 'react';
import images, { Component } from 'react';

<img src={require('./Christmas.jpg')}/>
